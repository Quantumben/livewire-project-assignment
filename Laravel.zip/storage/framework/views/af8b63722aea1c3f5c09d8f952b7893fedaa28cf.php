<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>TodoList APP</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
            fontFamily: {
                sans: ["Roboto", "sans-serif"],
                body: ["Roboto", "sans-serif"],
                mono: ["ui-monospace", "monospace"],
            },
            },
        };
    </script>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>

   <?php echo $__env->yieldContent('content'); ?>

   <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>
<?php /**PATH /home/quantumben/Desktop/JCWORLD/beeproger task - backend(Laravel)/resources/views/layouts/app.blade.php ENDPATH**/ ?>